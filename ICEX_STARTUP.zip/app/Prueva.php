<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Prueva extends Model
{
    //
    /*protected $table = 'pruevas';
    public $timestamps =false;*/
}
