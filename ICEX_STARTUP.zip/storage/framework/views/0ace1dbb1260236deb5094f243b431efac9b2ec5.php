<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="css/main-moca.css" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    <title>acex|analisis de mercado</title>
  </head>
  <body>
	  <!--SECTION OF NAVBAR-->
		<section class="container-fluid bg-white sombra-moca">
			<div class="container">
				<nav class="navbar navbar-expand-lg navbar-light bg-white">
						<a class="navbar-brand" href="/">
							<img src="images/logo-icex.png" height="30" class="d-inline-block align-top" alt="">
						</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>
					<div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNav">
						<ul class="navbar-nav">
							<li class="nav-item">
								<a class="nav-link p-2 text-nav-moca" href="/">INICIO</a>
							</li>
							<li class="nav-item active">
								<a class="nav-link p-2 text-nav-moca" href="/inteligencia">INTELIGENCIA COMERCIAL</a>
							</li>
							<li class="nav-item">
								<a class="nav-link p-2 text-nav-moca" href="/analisis">ANALISIS DE MERCADO</a>
							</li>
							<li class="nav-item">
								<a class="nav-link p-2 text-nav-moca" href="#" role="button" aria-expanded="false" aria-haspopup="true">
									<?php echo e(Auth::user()->nombre); ?> <span class="caret"></span>
								</a>
							</li>
							<li class="nav-item">
								<a class="nav-link p-2 text-nav-moca"  href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
									SALIR
								</a>
								<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
									<?php echo e(csrf_field()); ?>

								</form>
							</li>
						</ul>
					</div>
				</nav>
			</div>
		</section><!--END SECTION OF NAVBAR-->
		<!---->
		<!--SECTION OF CONTENIDO-->
		<section class="container-fluid">
				<div class="container">
					
                    <div class="row">
                        <div>
                            <div class="card mt-2 bg-light">
								<div class="card-header fondomoca-asul">
									<i class="material-icons">swap_vert</i>
										Top productos
								</div>
								<div class="card-body">
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th scope="col">partida</th>
                                                <th scope="col">Aduana</th>
                                                <th scope="col">Numero</th>
                                                <th scope="col">fecha</th>
                                                <th scope="col">Nombre comercial</th>
                                                <th scope="col">Importador</th>
                                                <th scope="col">Pais</th>
												<th scope="col">Puerto</th>
												<th scope="col">Peso_neto</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $informacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($informacion->partida); ?></td>
                                                    <td><?php echo e($informacion->aduana); ?></td>
                                                    <td><?php echo e($informacion->numero); ?></td>
                                                    <td><?php echo e($informacion->fecha); ?></td>
                                                    <td><?php echo e($informacion->nombre_comercial); ?></td>
                                                    <td><a href="https://www.google.com/search?client=windows&channel=fs&ei=mZyUWqrVBYOG5wL34Y3ABg&q=<?php echo e($informacion->inportador); ?>&oq=<?php echo e($informacion->inportador); ?>&gs_l=psy-ab.3..0i71k1l5.0.0.0.2654.0.0.0.0.0.0.0.0..0.0....0...1c..64.psy-ab..0.0.0....0.0_CAw8j_O_0" target="_blank"><?php echo e($informacion->inportador); ?></a></td>
                                                    <td><?php echo e($informacion->pais); ?></td>
													<td><?php echo e($informacion->puerto); ?></td>	
													<td><?php echo e($informacion->peso_neto); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
									<?php echo e($informacions->render("pagination::bootstrap-4")); ?>

                                </div>
                            </div>
                        </div>
                    </div>
				</div>
			</section>
		
    <!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script type="text/javascript" src="js/jquery.vmap.sampledata.js"></script>
	<script type="text/javascript" src="js/jquery.vmap.js"></script>
	<script type="text/javascript" src="js/maps/jquery.vmap.world.js" charset="utf-8"></script>
	<script type="text/javascript" src="js/main-moca.js" charset="utf-8"></script>

    <script>
			jQuery(document).ready(function () {
			  jQuery('#vmap').vectorMap({
				map: 'world_en',
				backgroundColor: '#273c75',
				color: '#ffffff',
				hoverOpacity: 0.7,
				selectedColor: '#666666',
				enableZoom: true,
				showTooltip: true,
				scaleColors: ['#C8EEFF', '#006491'],
				values: sample_data,
				normalizeFunction: 'polynomial'
			  });
			});
		  </script>
  </body>
</html>